
import 'package:flutter/material.dart';

import 'app.dart';

void main() {
/*  DevicePreview(
    enabled: !kReleaseMode,
    builder: (context) => App(), // Wrap your app
  );*/
runApp(const App());

}
